import argparse
import logging
from aristotlelib.cli.api_action import APIAction
from aristotlelib.project import Project


class CancelAction(APIAction):
    @property
    def command_name(self) -> str:
        return "cancel"

    @property
    def description(self) -> str:
        return "Cancels an in-progress (or queued) project."

    def add_action_arguments(self) -> None:
        self.parser.add_argument("project_id", type=str)

    async def run_action(self, args: argparse.Namespace) -> None:
        project = await Project.from_id(args.project_id)
        await project.cancel()
        logging.info(f"Project {project.project_id} canceled.")
