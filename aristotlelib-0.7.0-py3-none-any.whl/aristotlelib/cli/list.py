import argparse
import logging
from aristotlelib.cli.api_action import APIAction
from aristotlelib.project import Project, ProjectStatus
from aristotlelib.date_utils import format_relative_time


class ListAction(APIAction):
    @property
    def command_name(self) -> str:
        return "list"

    @property
    def description(self) -> str:
        return "Lists past projects, in descending order by created date."

    def add_action_arguments(self) -> None:
        self.parser.add_argument(
            "--status",
            nargs="+",
            choices=[s.value for s in ProjectStatus if s != ProjectStatus.UNKNOWN],
            help="Filter by project status(es). Can specify multiple values.",
        )
        self.parser.add_argument(
            "--limit",
            type=int,
            default=10,
            help="Maximum number of projects to return (1-100). Default: 10",
        )
        self.parser.add_argument(
            "--pagination-key",
            type=str,
            help="Pagination key to start from when retrieving projects.",
        )

    async def run_action(self, args: argparse.Namespace) -> None:
        status_filter = None
        if args.status:
            try:
                status_filter = [ProjectStatus(s) for s in args.status]
            except ValueError:
                logging.error(f"Invalid statuses: {args.status}")
                return

        projects, pagination_key = await Project.list_projects(
            pagination_key=args.pagination_key,
            limit=args.limit,
            status=status_filter,
        )

        if not projects:
            logging.info("No projects found.")
            return

        # Print header with proper column widths
        print(f"{'ID':<36} {'STATUS':<15} {'CREATED':<20} {'PROGRESS':<10}")
        print("-" * 85)

        # Print each project as a row
        for project in projects:
            project_id = project.project_id
            status = project.status.name
            created = format_relative_time(project.created_at)
            progress = (
                f"{project.percent_complete}%"
                if project.percent_complete is not None
                else "-"
            )

            print(f"{project_id:<36} {status:<15} {created:<20} {progress:<10}")

        if pagination_key:
            logging.info(f"\nPagination key for next page: {pagination_key}")
