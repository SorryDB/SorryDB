import argparse
from pathlib import Path
from aristotlelib.cli.api_action import APIAction
from aristotlelib.project import Project
import logging


class SubmitAction(APIAction):
    @property
    def command_name(self) -> str:
        return "submit"

    @property
    def description(self) -> str:
        return "Submits a new project to aristotle."

    def add_action_arguments(self) -> None:
        self.parser.add_argument("prompt", type=str, help="Instructions to Aristotle")

        self.parser.add_argument(
            "--project-dir",
            type=Path,
            help="Any files that aristotle will need in one directory, like your lean project or paper to formalize.",
        )

        self.parser.add_argument(
            "--wait",
            action="store_true",
            help="Wait for completion before returning (default: don't wait)",
        )

        self.parser.add_argument(
            "--destination",
            type=str,
            help="Path to save the solution directory. Only used if --wait is True.",
        )

    async def run_action(self, args: argparse.Namespace) -> None:
        if args.project_dir:
            if not args.project_dir.is_dir():
                raise ValueError(
                    f"--project-dir must be a valid directory: {args.project_dir}"
                )

            project = await Project.create_from_directory(
                prompt=args.prompt,
                project_dir=args.project_dir,
            )
        else:
            project = await Project.create(prompt=args.prompt)

        logging.info(f"Project created: {project.project_id}")
        if args.wait:
            await project.wait_for_completion(
                destination=args.destination,
            )
