import argparse
from pathlib import Path
from aristotlelib.cli.api_action import APIAction
from aristotlelib.project import Project
import logging
import tarfile
import tempfile


class FormalizeAction(APIAction):
    @property
    def command_name(self) -> str:
        return "formalize"

    @property
    def description(self) -> str:
        return "Submits a new project to aristotle to formalize a file."

    def add_action_arguments(self) -> None:
        self.parser.add_argument("input_file", type=Path, help="A file to formalize")

        self.parser.add_argument(
            "--wait",
            action="store_true",
            help="Wait for completion before returning (default: don't wait)",
        )

        self.parser.add_argument(
            "--destination",
            type=str,
            help="Path to save the solution directory. Only used if --wait is True.",
        )

    async def run_action(self, args: argparse.Namespace) -> None:
        if not args.input_file.is_file():
            raise ValueError(
                "Input file must be a valid file. If you need to provide multiple files, you can run `aristotle submit` instead and tell it what to formalize."
            )

        filename = args.input_file.name
        prompt = f"Formalize {filename}"

        with tempfile.TemporaryDirectory() as temp_dir:
            public_file_path = f"{args.input_file.stem}.tar.gz"
            tar_file_path = Path(temp_dir) / public_file_path

            with tarfile.open(tar_file_path, "w:gz") as tar:
                tar.add(args.input_file, arcname=filename)

            project = await Project.create(
                prompt=prompt,
                tar_file_path=tar_file_path,
                public_file_path=public_file_path,
            )

        logging.info(f"Project created: {project.project_id}")
        if args.wait:
            await project.wait_for_completion(
                destination=args.destination,
            )
