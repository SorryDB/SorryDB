from __future__ import annotations

import argparse
import asyncio
import logging
from abc import ABC, abstractmethod

from aristotlelib.api_request import get_api_key, set_api_key, AristotleAPIError


class APIAction(ABC):
    def __init__(
        self, subparsers: argparse._SubParsersAction[argparse.ArgumentParser]
    ) -> None:
        self.parser = subparsers.add_parser(
            self.command_name,
            help=self.description,
            description=self.description,
        )

    @property
    def command_name(self) -> str:
        raise NotImplementedError()

    @property
    def description(self) -> str:
        raise NotImplementedError()

    @abstractmethod
    def add_action_arguments(self) -> None: ...

    @abstractmethod
    async def run_action(self, args: argparse.Namespace) -> None: ...

    def add_common_arguments(self) -> None:
        self.parser.add_argument(
            "--api-key",
            type=str,
            help="Aristotle API key (can also be set via ARISTOTLE_API_KEY environment variable)",
        )

    def add_arguments(self) -> None:
        self.add_common_arguments()
        self.add_action_arguments()
        self.parser.set_defaults(func=self.run)

    def validate(self) -> bool:
        try:
            get_api_key()
            return True
        except ValueError:
            error_msg = (
                "Aristotle API key not found.\n"
                "To get started with the Aristotle CLI:\n"
                "1. Create an API key at https://aristotle.harmonic.fun/dashboard/keys\n"
                "2. Add it to your environment with `export ARISTOTLE_API_KEY=<your-key>`\n"
                "OR use it per-command with aristotle <command> --api-key <your-key>"
            )
            logging.error(error_msg)
            return False

    def run(self, args: argparse.Namespace) -> None:
        logging.basicConfig(level=logging.INFO, format="%(levelname)s - %(message)s")

        # Disable httpx and httpcore logging
        logging.getLogger("httpx").disabled = True
        logging.getLogger("httpcore").disabled = True

        if args.api_key is not None:
            set_api_key(args.api_key)

        if not self.validate():
            return

        try:
            asyncio.run(self.run_action(args))
        except AristotleAPIError as e:
            if e.status_code == 401:
                error_msg = (
                    "Invalid API key. Please check your API key and try again.\n"
                    "Get a valid API key at https://aristotle.harmonic.fun/dashboard/keys\n"
                    "Set your API key using `export ARISTOTLE_API_KEY=[key]` or by using the --api-key flag in a request."
                )
                logging.error(error_msg)
            elif e.status_code == 429:
                error_msg = "You have too many requests. Cancel one or wait until one completes before submitting another."
                logging.error(error_msg)
            else:
                raise
