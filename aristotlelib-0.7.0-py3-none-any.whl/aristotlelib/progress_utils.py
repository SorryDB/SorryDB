def create_progress_bar(percent: int | None, width: int = 30) -> str:
    """Create a visual progress bar."""
    if percent is None:
        percent = 0

    # Ensure at least 1 filled character if percent > 0 and < 100
    if 0 < percent < 100:
        filled = max(1, int(width * percent / 100))
    else:
        filled = int(width * percent / 100)

    bar = "█" * filled + "░" * (width - filled)
    return f"[{bar}] {percent}%"


def print_progress_lines(lines: list[str]) -> None:
    """Print multiple lines of progress that overwrite the previous display.

    Args:
        lines: List of lines to display. Leaves cursor on blank line below for clean output.
    """
    if not lines:
        return

    # Move cursor up to overwrite previous display (if this isn't the first call)
    print(f"\033[{len(lines)}A", end="")

    # Print each line, clearing it first
    for line in lines:
        print("\r\033[K" + line)

    # Flush output, cursor is now on blank line below
    print("", end="", flush=True)


def clear_progress_lines(num_lines: int) -> None:
    """Clear a multi-line progress display.

    Args:
        num_lines: Number of lines to clear. Leaves cursor at the first line position.
    """
    # Move cursor up to the first line
    print(f"\033[{num_lines}A", end="")

    # Clear all lines and stay at first line
    for _ in range(num_lines):
        print("\r\033[K\n", end="")

    # Move back up to first line
    print(f"\033[{num_lines}A\r", end="", flush=True)
