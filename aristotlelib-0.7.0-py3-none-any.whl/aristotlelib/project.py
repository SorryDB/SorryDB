import asyncio
import json
import logging
import pydantic  # type: ignore
import tarfile
import tempfile
from datetime import datetime
from pathlib import Path
from enum import Enum
from typing import Any, cast

from aristotlelib import api_request, local_file_utils, progress_utils
from aristotlelib.date_utils import format_relative_time, format_elapsed_time

# Set up logger for this module
logger = logging.getLogger("aristotle")

MAX_FILES_PER_REQUEST = 10

# Polling and backoff constants for wait_for_completion
DEFAULT_MAX_FAILURE_TIME_SECONDS = 600  # 10 minutes
DEFAULT_MIN_BACKOFF_SECONDS = 15
DEFAULT_MAX_BACKOFF_SECONDS = 120  # 2 minutes

NUM_COMPACT_PRINT_LINES = 3


class ProjectStatus(Enum):
    UNKNOWN = "UNKNOWN"  # Fallback for unrecognized statuses from server
    NOT_STARTED = "NOT_STARTED"  # Deprecated. Only legacy projects have this.
    QUEUED = "QUEUED"  # Project will start soon
    IN_PROGRESS = "IN_PROGRESS"  # Project is actively in progress
    COMPLETE = "COMPLETE"  # Project successfully completed
    COMPLETE_WITH_ERRORS = "COMPLETE_WITH_ERRORS"  # Project finished but there were errors processing the input
    OUT_OF_BUDGET = "OUT_OF_BUDGET"  # Project could not complete in time
    FAILED = "FAILED"  # Unexpected error
    CANCELED = "CANCELED"  # Project was canceled


class Project(pydantic.BaseModel):
    project_id: str
    status: ProjectStatus
    created_at: datetime
    last_updated_at: datetime
    percent_complete: int | None = None
    input_prompt: str | None = None
    file_name: str | None = None
    description: str | None = None

    @pydantic.field_validator("status", mode="before")
    @classmethod
    def validate_status(cls, v):
        """Handle unknown status values gracefully by mapping them to UNKNOWN."""
        try:
            return ProjectStatus(v)
        except ValueError:
            logger.warning(
                f"Unknown project status '{v}' from server, treating as UNKNOWN"
            )
            return ProjectStatus.UNKNOWN

    def __str__(self) -> str:
        ret = f"Project {self.project_id}"
        if self.input_prompt is not None:
            ret += f"\n{self.input_prompt}"
        if self.file_name is not None:
            ret += f"\nfile name: {self.file_name}"
        ret += f"\nstatus: {self.status.name}\ncreated: {format_relative_time(self.created_at)}\nlast updated: {format_relative_time(self.last_updated_at)}"
        if self.percent_complete is not None:
            ret += f"\npercent complete: {self.percent_complete}"
        return ret

    def print_compact(self) -> None:
        to_print = [f"Project {self.project_id}"]
        elapsed_seconds = int((datetime.now() - self.created_at).total_seconds())
        elapsed_str = format_elapsed_time(elapsed_seconds)

        # Only show progress bar when IN_PROGRESS
        if self.status == ProjectStatus.IN_PROGRESS:
            progress_bar = progress_utils.create_progress_bar(self.percent_complete)
            to_print.append(f"{progress_bar} ({elapsed_str})")
            to_print.append(f"Status: {self.status.name}")
        else:
            to_print.append(f"Status: {self.status.name} ({elapsed_str})")

        progress_utils.print_progress_lines(to_print)

    @classmethod
    async def from_id(cls, project_id: str) -> "Project":
        project = Project(
            project_id=project_id,
            status=ProjectStatus.UNKNOWN,
            created_at=datetime.now(),
            last_updated_at=datetime.now(),
        )
        await project.refresh()
        return project

    @classmethod
    async def create(
        cls,
        prompt: str,
        tar_file_path: Path | str | None = None,
        public_file_path: str | None = None,
    ) -> "Project":
        """Create a project from a prompt and a tar file.

        Args:
            prompt: Tells Aristotle what to do.
            tar_file_path: Path to the tar file to upload.
            public_file_path: Public path to use for the uploaded file. If None, uses the tar_file_path.

        Returns:
            The created Project instance.
        """
        body = json.dumps({"prompt": prompt})
        files = None
        public_file_path = public_file_path or str(tar_file_path)

        if tar_file_path is not None:
            tar_file_path = Path(tar_file_path)
            tar_file_content = local_file_utils.read_file_safely(tar_file_path)
            files = [
                ("input", (public_file_path, tar_file_content, "application/x-tar"))
            ]

        async with api_request.AristotleRequestClient() as client:
            response = await client.post("/project", data={"body": body}, files=files)
            return cls.model_validate(response.json())

    @classmethod
    async def create_from_directory(
        cls,
        prompt: str,
        project_dir: Path | str,
    ) -> "Project":
        """Create a project from a directory by creating a tar.gz archive.

        Automatically skips files that Aristotle wouldn't need to process.

        Args:
            prompt: Tells Aristotle what to do.
            project_dir: Path to the directory with any supplementary files, e.g. a Lean project.

        Returns:
            The created Project instance.

        Raises:
            ValueError: If the path is not a directory.
        """
        project_dir = Path(project_dir)
        if not project_dir.is_dir():
            raise ValueError(f"Path is not a directory: {project_dir}")

        with tempfile.TemporaryDirectory() as temp_dir:
            tar_file_path = Path(temp_dir) / f"{project_dir.name}.tar.gz"

            with tarfile.open(tar_file_path, "w:gz") as tar:
                for file_path in project_dir.glob("**/*"):
                    if not file_path.is_file():
                        continue

                    rel_path = file_path.relative_to(project_dir)

                    # Skip files matching ignore patterns
                    if local_file_utils.should_skip_input_file(
                        file_path, base_path=project_dir
                    ):
                        logger.debug(f"Skipping ignored file: {rel_path}")
                        continue

                    tar.add(file_path, arcname=str(rel_path))

            return await cls.create(
                prompt=prompt,
                tar_file_path=tar_file_path,
                public_file_path=f"{project_dir.name}.tar.gz",
            )

    async def get_solution_if_complete(self, destination: Path | str | None = None):
        if self.status == ProjectStatus.FAILED:
            raise api_request.AristotleAPIError(
                "Project failed due to an internal error. The team at Harmonic has been notified; please try again."
            )
        elif self.status == ProjectStatus.CANCELED:
            logger.info("Project was canceled.")
            return None
        elif self.status in (
            ProjectStatus.COMPLETE,
            ProjectStatus.COMPLETE_WITH_ERRORS,
            ProjectStatus.OUT_OF_BUDGET,
        ):
            if self.status == ProjectStatus.COMPLETE:
                logger.info("Project complete! Getting results...")
            elif self.status == ProjectStatus.COMPLETE_WITH_ERRORS:
                logger.info(
                    "Project finished but had trouble parsing the input. Getting the results..."
                )
            elif self.status == ProjectStatus.OUT_OF_BUDGET:
                logger.info(
                    "Project ran out of budget. You can resume by starting a new project with this output and the same prompt. Getting output..."
                )
            solution_file_path = await self.get_solution(destination=destination)
            logger.info(f"Project saved to {solution_file_path}")
            return str(solution_file_path)
        else:
            # queued or in progress; print the progress bar
            self.print_compact()
            return None

    async def get_solution(self, destination: Path | str | None = None) -> Path:
        """Download the solution file from the project result endpoint.

        Args:
            destination: Path where to save the downloaded file. If None, uses filename from response headers.

        Returns:
            Path to the downloaded file
        """
        async with api_request.AristotleRequestClient() as client:
            response = await client.get(f"/project/{self.project_id}/result")

            if destination is None:
                content_disposition = response.headers.get("content-disposition", "")
                if "filename=" in content_disposition:
                    filename = content_disposition.split("filename=")[1].strip('"')
                    destination = Path(filename)
                else:
                    destination = Path(f"{self.project_id}_aristotle.tar.gz")
            else:
                destination = Path(destination)

            destination.write_bytes(response.content)
            return destination

    async def get_input(self, destination: Path | str | None = None) -> Path:
        """Downloads the input project."""
        async with api_request.AristotleRequestClient() as client:
            response = await client.get(f"/project/{self.project_id}/input")

            if destination is not None:
                destination = Path(destination)
            else:
                content_disposition = response.headers.get("content-disposition", "")
                if "filename=" in content_disposition:
                    filename = content_disposition.split("filename=")[1].strip('"')
                    destination = Path(filename)
                elif self.file_name:
                    destination = Path(self.file_name)
                else:
                    destination = Path(f"{self.project_id}.tar.gz")

            destination.write_bytes(response.content)
            return destination

    async def refresh(self) -> None:
        """Refreshes the project instance with the most up to date data."""
        async with api_request.AristotleRequestClient() as client:
            response = await client.get(f"/project/{self.project_id}")
            response_data = response.json()
            self._update_from_response(response_data)

    async def cancel(self) -> None:
        """Cancel the project if it is in progress or queued."""
        async with api_request.AristotleRequestClient() as client:
            response = await client.post(f"/project/{self.project_id}/cancel")
            response_data = response.json()
            self._update_from_response(response_data)

    def _update_from_response(self, response_data: dict) -> None:
        updated_project = self.model_validate(response_data)
        for field_name, field_value in updated_project.model_dump().items():
            setattr(self, field_name, field_value)

    @classmethod
    async def list_projects(
        cls,
        pagination_key: str | None = None,
        limit: int = 30,
        status: ProjectStatus | list[ProjectStatus] | None = None,
    ) -> tuple[list["Project"], str | None]:
        """List projects, ordered by creation date (most recent first).

        Args:
            pagination_key: Key to start from when paginating through projects.
            limit: Maximum number of projects to return. Must be between 1 and 100.
            status: Optional project status filter. Can be a single ProjectStatus,
                   a list of ProjectStatus values, or None for all projects.

        Returns:
            Tuple of list of projects and the new pagination key.
        """
        assert 1 <= limit <= 100, "Limit must be between 1 and 100"

        params: dict[str, Any] = {"pagination_key": pagination_key, "limit": limit}
        if status is not None:
            if isinstance(status, list):
                # Convert list of ProjectStatus to list of status strings
                params["status"] = [s.value for s in status]
            else:
                # Single ProjectStatus
                params["status"] = status.value

        async with api_request.AristotleRequestClient() as client:
            response = await client.get("/project", params=params)
            response_data = response.json()
            projects: list["Project"] = [
                cast("Project", cls.model_validate(project))
                for project in response_data["projects"]
            ]
            pagination_key = response_data.get("pagination_key")
            assert pagination_key is None or isinstance(pagination_key, str)
            return projects, pagination_key

    async def wait_for_completion(
        self,
        destination: Path | str | None = None,
        polling_interval_seconds: int = 30,
    ) -> str | None:
        total_failure_time = 0
        num_polling_failures = 0
        should_clear_progress_bar = False

        try:
            await self.refresh()

            # Reserve space for progress display by printing blank lines first
            # This prevents the progress bar from overwriting the command prompt
            if self.status in (ProjectStatus.IN_PROGRESS, ProjectStatus.QUEUED):
                should_clear_progress_bar = True
                for _ in range(NUM_COMPACT_PRINT_LINES):
                    print()

            while self.status in (ProjectStatus.QUEUED, ProjectStatus.IN_PROGRESS):
                try:
                    self.print_compact()
                    await asyncio.sleep(polling_interval_seconds)
                    await self.refresh()

                    # Reset failure tracking on successful refresh
                    num_polling_failures = 0
                    total_failure_time = 0

                except api_request.AristotleAPIError:
                    num_polling_failures += 1
                    # Calculate exponential backoff: 15s, 30s, 60s, 120s, 120s...
                    backoff_seconds = min(
                        DEFAULT_MIN_BACKOFF_SECONDS * (2 ** (num_polling_failures - 1)),
                        DEFAULT_MAX_BACKOFF_SECONDS,
                    )
                    total_failure_time += backoff_seconds

                    if total_failure_time >= DEFAULT_MAX_FAILURE_TIME_SECONDS:
                        raise api_request.AristotleAPIError(
                            f"Connection interrupted - Aristotle is still at work. Try reconnecting with project id {self.project_id}."
                        )

                    await asyncio.sleep(backoff_seconds)

            # Clear progress bar if we showed it
            if should_clear_progress_bar:
                progress_utils.clear_progress_lines(NUM_COMPACT_PRINT_LINES)
                should_clear_progress_bar = False

            return await self.get_solution_if_complete(destination=destination)
        finally:
            if should_clear_progress_bar:
                progress_utils.clear_progress_lines(NUM_COMPACT_PRINT_LINES)

            if self.status in (
                ProjectStatus.IN_PROGRESS,
                ProjectStatus.QUEUED,
            ):
                logger.info(f"Project {self.project_id} is still running.")
